<article class="no-results post card bg-white shadow-sm border-0">
	<header class="post-header text-center">
		<i style="font-size:80px;opacity:.6;margin-top:30px;margin-bottom:15px;" aria-hidden="true" class="fa fa-folder-o"></i>
		<h1 class="post-title"><?php _e('此分类没有文章', 'argon');?></h1>
		<span><?php _e('这里什么都没有', 'argon');?></span>
		<br>
		<a href="javascript:window.history.back(-1);" ondragstart="return false;" class="btn btn-outline-primary" style="margin-top:45px;">
			<span class="btn-inner--icon"><i class="fa fa-chevron-left"></i></span>
			<span class="btn-inner--text"><?php _e('返回上一页', 'argon');?></span>
		</a>
	</header>
</article>